Source code đặt tại thư mục 'src'
Thực thi chương trình: ./filename hoặc python filename

Bài                 |   File                |
--------------------------------------------|
2.4.1               |   ./2.4.1.jpg         |
2.4.2               |   ./2.4.2.jpg         |
Fibonacci           |   ./src/fibonacci.py  |
Biểu diễn nhị phân  |   ./src/dec2bin.py    |
Bài tự thiết kế     |   ./src/powof2.py     |
---------------------------------------------
